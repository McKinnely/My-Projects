﻿namespace Tech_Jeopardy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.cmpTiaSecBtn1 = new System.Windows.Forms.Button();
            this.linuxBtn1 = new System.Windows.Forms.Button();
            this.cSharpBtn1 = new System.Windows.Forms.Button();
            this.javaBtn1 = new System.Windows.Forms.Button();
            this.ntwrkBtn1 = new System.Windows.Forms.Button();
            this.cmpSciBtn1 = new System.Windows.Forms.Button();
            this.cmpTiaSecBtn2 = new System.Windows.Forms.Button();
            this.linuxBtn2 = new System.Windows.Forms.Button();
            this.cSharpBtn2 = new System.Windows.Forms.Button();
            this.javaBtn2 = new System.Windows.Forms.Button();
            this.ntwrkBtn2 = new System.Windows.Forms.Button();
            this.cmpSciBtn2 = new System.Windows.Forms.Button();
            this.cmpTiaSecBtn3 = new System.Windows.Forms.Button();
            this.linuxBtn3 = new System.Windows.Forms.Button();
            this.cSharpBtn3 = new System.Windows.Forms.Button();
            this.javaBtn3 = new System.Windows.Forms.Button();
            this.ntwrkBtn3 = new System.Windows.Forms.Button();
            this.cmpSciBtn3 = new System.Windows.Forms.Button();
            this.cmpTiaSecBtn4 = new System.Windows.Forms.Button();
            this.linuxBtn4 = new System.Windows.Forms.Button();
            this.cSharpBtn4 = new System.Windows.Forms.Button();
            this.javaBtn4 = new System.Windows.Forms.Button();
            this.ntwrkBtn4 = new System.Windows.Forms.Button();
            this.cmpSciBtn4 = new System.Windows.Forms.Button();
            this.qstnLbl = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.usrAnswrBtn = new System.Windows.Forms.Button();
            this.cpuAnswrBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cpuRt_Or_WrngLbl = new System.Windows.Forms.Label();
            this.useRt_Or_WrngLbl = new System.Windows.Forms.Label();
            this.athenaScore = new System.Windows.Forms.Label();
            this.humanScore = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cpuQstnLbl = new System.Windows.Forms.Label();
            this.cpuTxtBx = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.userTimerLbl = new System.Windows.Forms.Label();
            this.usrTxtBx = new System.Windows.Forms.TextBox();
            this.usrQstnLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timerLbl = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(13, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 62);
            this.button1.TabIndex = 0;
            this.button1.Text = "COMPTIA SEC+";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Location = new System.Drawing.Point(183, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(164, 62);
            this.button2.TabIndex = 1;
            this.button2.Text = "THINKING LINUX";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Location = new System.Drawing.Point(353, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(164, 62);
            this.button3.TabIndex = 2;
            this.button3.Text = "I SEE SHARP";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Location = new System.Drawing.Point(523, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(164, 62);
            this.button4.TabIndex = 3;
            this.button4.Text = "A CUP OF JAVA";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Location = new System.Drawing.Point(693, 13);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(164, 62);
            this.button5.TabIndex = 4;
            this.button5.Text = "NOT ON MY NETWORK";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Location = new System.Drawing.Point(862, 13);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(164, 62);
            this.button6.TabIndex = 5;
            this.button6.Text = "COMPUTER SCIENCE";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // cmpTiaSecBtn1
            // 
            this.cmpTiaSecBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpTiaSecBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmpTiaSecBtn1.Location = new System.Drawing.Point(13, 81);
            this.cmpTiaSecBtn1.Name = "cmpTiaSecBtn1";
            this.cmpTiaSecBtn1.Size = new System.Drawing.Size(164, 62);
            this.cmpTiaSecBtn1.TabIndex = 11;
            this.cmpTiaSecBtn1.Text = "$100";
            this.cmpTiaSecBtn1.UseVisualStyleBackColor = true;
            this.cmpTiaSecBtn1.Click += new System.EventHandler(this.CmpTiaSecBtn1_Click);
            // 
            // linuxBtn1
            // 
            this.linuxBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linuxBtn1.Location = new System.Drawing.Point(183, 81);
            this.linuxBtn1.Name = "linuxBtn1";
            this.linuxBtn1.Size = new System.Drawing.Size(164, 62);
            this.linuxBtn1.TabIndex = 10;
            this.linuxBtn1.Text = "$100";
            this.linuxBtn1.UseVisualStyleBackColor = true;
            this.linuxBtn1.Click += new System.EventHandler(this.LinuxBtn1_Click);
            // 
            // cSharpBtn1
            // 
            this.cSharpBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cSharpBtn1.Location = new System.Drawing.Point(353, 81);
            this.cSharpBtn1.Name = "cSharpBtn1";
            this.cSharpBtn1.Size = new System.Drawing.Size(164, 62);
            this.cSharpBtn1.TabIndex = 9;
            this.cSharpBtn1.Text = "$100";
            this.cSharpBtn1.UseVisualStyleBackColor = true;
            this.cSharpBtn1.Click += new System.EventHandler(this.CSharpBtn1_Click);
            // 
            // javaBtn1
            // 
            this.javaBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.javaBtn1.Location = new System.Drawing.Point(522, 81);
            this.javaBtn1.Name = "javaBtn1";
            this.javaBtn1.Size = new System.Drawing.Size(164, 62);
            this.javaBtn1.TabIndex = 8;
            this.javaBtn1.Text = "$100";
            this.javaBtn1.UseVisualStyleBackColor = true;
            this.javaBtn1.Click += new System.EventHandler(this.JavaBtn1_Click);
            // 
            // ntwrkBtn1
            // 
            this.ntwrkBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ntwrkBtn1.Location = new System.Drawing.Point(692, 81);
            this.ntwrkBtn1.Name = "ntwrkBtn1";
            this.ntwrkBtn1.Size = new System.Drawing.Size(164, 62);
            this.ntwrkBtn1.TabIndex = 7;
            this.ntwrkBtn1.Text = "$100";
            this.ntwrkBtn1.UseVisualStyleBackColor = true;
            this.ntwrkBtn1.Click += new System.EventHandler(this.NtwrkBtn1_Click);
            // 
            // cmpSciBtn1
            // 
            this.cmpSciBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpSciBtn1.Location = new System.Drawing.Point(862, 81);
            this.cmpSciBtn1.Name = "cmpSciBtn1";
            this.cmpSciBtn1.Size = new System.Drawing.Size(164, 62);
            this.cmpSciBtn1.TabIndex = 6;
            this.cmpSciBtn1.Text = "$100";
            this.cmpSciBtn1.UseVisualStyleBackColor = true;
            this.cmpSciBtn1.Click += new System.EventHandler(this.CmpSciBtn1_Click);
            // 
            // cmpTiaSecBtn2
            // 
            this.cmpTiaSecBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpTiaSecBtn2.Location = new System.Drawing.Point(13, 149);
            this.cmpTiaSecBtn2.Name = "cmpTiaSecBtn2";
            this.cmpTiaSecBtn2.Size = new System.Drawing.Size(164, 62);
            this.cmpTiaSecBtn2.TabIndex = 17;
            this.cmpTiaSecBtn2.Text = "$300";
            this.cmpTiaSecBtn2.UseVisualStyleBackColor = true;
            this.cmpTiaSecBtn2.Click += new System.EventHandler(this.CmpTiaSecBtn2_Click);
            // 
            // linuxBtn2
            // 
            this.linuxBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linuxBtn2.Location = new System.Drawing.Point(183, 149);
            this.linuxBtn2.Name = "linuxBtn2";
            this.linuxBtn2.Size = new System.Drawing.Size(164, 62);
            this.linuxBtn2.TabIndex = 16;
            this.linuxBtn2.Text = "$300";
            this.linuxBtn2.UseVisualStyleBackColor = true;
            this.linuxBtn2.Click += new System.EventHandler(this.LinuxBtn2_Click);
            // 
            // cSharpBtn2
            // 
            this.cSharpBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cSharpBtn2.Location = new System.Drawing.Point(353, 149);
            this.cSharpBtn2.Name = "cSharpBtn2";
            this.cSharpBtn2.Size = new System.Drawing.Size(164, 62);
            this.cSharpBtn2.TabIndex = 15;
            this.cSharpBtn2.Text = "$300";
            this.cSharpBtn2.UseVisualStyleBackColor = true;
            this.cSharpBtn2.Click += new System.EventHandler(this.CSharpBtn2_Click);
            // 
            // javaBtn2
            // 
            this.javaBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.javaBtn2.Location = new System.Drawing.Point(523, 149);
            this.javaBtn2.Name = "javaBtn2";
            this.javaBtn2.Size = new System.Drawing.Size(164, 62);
            this.javaBtn2.TabIndex = 14;
            this.javaBtn2.Text = "$300";
            this.javaBtn2.UseVisualStyleBackColor = true;
            this.javaBtn2.Click += new System.EventHandler(this.JavaBtn2_Click);
            // 
            // ntwrkBtn2
            // 
            this.ntwrkBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ntwrkBtn2.Location = new System.Drawing.Point(693, 149);
            this.ntwrkBtn2.Name = "ntwrkBtn2";
            this.ntwrkBtn2.Size = new System.Drawing.Size(164, 62);
            this.ntwrkBtn2.TabIndex = 13;
            this.ntwrkBtn2.Text = "$300";
            this.ntwrkBtn2.UseVisualStyleBackColor = true;
            this.ntwrkBtn2.Click += new System.EventHandler(this.NtwrkBtn2_Click);
            // 
            // cmpSciBtn2
            // 
            this.cmpSciBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpSciBtn2.Location = new System.Drawing.Point(862, 149);
            this.cmpSciBtn2.Name = "cmpSciBtn2";
            this.cmpSciBtn2.Size = new System.Drawing.Size(164, 62);
            this.cmpSciBtn2.TabIndex = 12;
            this.cmpSciBtn2.Text = "$300";
            this.cmpSciBtn2.UseVisualStyleBackColor = true;
            this.cmpSciBtn2.Click += new System.EventHandler(this.CmpSciBtn2_Click);
            // 
            // cmpTiaSecBtn3
            // 
            this.cmpTiaSecBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpTiaSecBtn3.Location = new System.Drawing.Point(13, 217);
            this.cmpTiaSecBtn3.Name = "cmpTiaSecBtn3";
            this.cmpTiaSecBtn3.Size = new System.Drawing.Size(164, 62);
            this.cmpTiaSecBtn3.TabIndex = 23;
            this.cmpTiaSecBtn3.Text = "$500";
            this.cmpTiaSecBtn3.UseVisualStyleBackColor = true;
            this.cmpTiaSecBtn3.Click += new System.EventHandler(this.CmpTiaSecBtn3_Click);
            // 
            // linuxBtn3
            // 
            this.linuxBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linuxBtn3.Location = new System.Drawing.Point(183, 217);
            this.linuxBtn3.Name = "linuxBtn3";
            this.linuxBtn3.Size = new System.Drawing.Size(164, 62);
            this.linuxBtn3.TabIndex = 22;
            this.linuxBtn3.Text = "$500";
            this.linuxBtn3.UseVisualStyleBackColor = true;
            this.linuxBtn3.Click += new System.EventHandler(this.LinuxBtn3_Click);
            // 
            // cSharpBtn3
            // 
            this.cSharpBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cSharpBtn3.Location = new System.Drawing.Point(353, 217);
            this.cSharpBtn3.Name = "cSharpBtn3";
            this.cSharpBtn3.Size = new System.Drawing.Size(164, 62);
            this.cSharpBtn3.TabIndex = 21;
            this.cSharpBtn3.Text = "$500";
            this.cSharpBtn3.UseVisualStyleBackColor = true;
            this.cSharpBtn3.Click += new System.EventHandler(this.CSharpBtn3_Click);
            // 
            // javaBtn3
            // 
            this.javaBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.javaBtn3.Location = new System.Drawing.Point(523, 217);
            this.javaBtn3.Name = "javaBtn3";
            this.javaBtn3.Size = new System.Drawing.Size(164, 62);
            this.javaBtn3.TabIndex = 20;
            this.javaBtn3.Text = "$500";
            this.javaBtn3.UseVisualStyleBackColor = true;
            this.javaBtn3.Click += new System.EventHandler(this.JavaBtn3_Click);
            // 
            // ntwrkBtn3
            // 
            this.ntwrkBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ntwrkBtn3.Location = new System.Drawing.Point(692, 217);
            this.ntwrkBtn3.Name = "ntwrkBtn3";
            this.ntwrkBtn3.Size = new System.Drawing.Size(164, 62);
            this.ntwrkBtn3.TabIndex = 19;
            this.ntwrkBtn3.Text = "$500";
            this.ntwrkBtn3.UseVisualStyleBackColor = true;
            this.ntwrkBtn3.Click += new System.EventHandler(this.NtwrkBtn3_Click);
            // 
            // cmpSciBtn3
            // 
            this.cmpSciBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpSciBtn3.Location = new System.Drawing.Point(862, 217);
            this.cmpSciBtn3.Name = "cmpSciBtn3";
            this.cmpSciBtn3.Size = new System.Drawing.Size(164, 62);
            this.cmpSciBtn3.TabIndex = 18;
            this.cmpSciBtn3.Text = "$500";
            this.cmpSciBtn3.UseVisualStyleBackColor = true;
            this.cmpSciBtn3.Click += new System.EventHandler(this.CmpSciBtn3_Click);
            // 
            // cmpTiaSecBtn4
            // 
            this.cmpTiaSecBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpTiaSecBtn4.Location = new System.Drawing.Point(12, 285);
            this.cmpTiaSecBtn4.Name = "cmpTiaSecBtn4";
            this.cmpTiaSecBtn4.Size = new System.Drawing.Size(164, 62);
            this.cmpTiaSecBtn4.TabIndex = 29;
            this.cmpTiaSecBtn4.Text = "$800";
            this.cmpTiaSecBtn4.UseVisualStyleBackColor = true;
            this.cmpTiaSecBtn4.Click += new System.EventHandler(this.CmpTiaSecBtn4_Click);
            // 
            // linuxBtn4
            // 
            this.linuxBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linuxBtn4.Location = new System.Drawing.Point(183, 285);
            this.linuxBtn4.Name = "linuxBtn4";
            this.linuxBtn4.Size = new System.Drawing.Size(164, 62);
            this.linuxBtn4.TabIndex = 28;
            this.linuxBtn4.Text = "$800";
            this.linuxBtn4.UseVisualStyleBackColor = true;
            this.linuxBtn4.Click += new System.EventHandler(this.LinuxBtn4_Click);
            // 
            // cSharpBtn4
            // 
            this.cSharpBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cSharpBtn4.Location = new System.Drawing.Point(353, 285);
            this.cSharpBtn4.Name = "cSharpBtn4";
            this.cSharpBtn4.Size = new System.Drawing.Size(164, 62);
            this.cSharpBtn4.TabIndex = 27;
            this.cSharpBtn4.Text = "$800";
            this.cSharpBtn4.UseVisualStyleBackColor = true;
            this.cSharpBtn4.Click += new System.EventHandler(this.CSharpBtn4_Click);
            // 
            // javaBtn4
            // 
            this.javaBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.javaBtn4.Location = new System.Drawing.Point(523, 285);
            this.javaBtn4.Name = "javaBtn4";
            this.javaBtn4.Size = new System.Drawing.Size(164, 62);
            this.javaBtn4.TabIndex = 26;
            this.javaBtn4.Text = "$800";
            this.javaBtn4.UseVisualStyleBackColor = true;
            this.javaBtn4.Click += new System.EventHandler(this.JavaBtn4_Click);
            // 
            // ntwrkBtn4
            // 
            this.ntwrkBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ntwrkBtn4.Location = new System.Drawing.Point(693, 285);
            this.ntwrkBtn4.Name = "ntwrkBtn4";
            this.ntwrkBtn4.Size = new System.Drawing.Size(164, 62);
            this.ntwrkBtn4.TabIndex = 25;
            this.ntwrkBtn4.Text = "$800";
            this.ntwrkBtn4.UseVisualStyleBackColor = true;
            this.ntwrkBtn4.Click += new System.EventHandler(this.NtwrkBtn4_Click);
            // 
            // cmpSciBtn4
            // 
            this.cmpSciBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmpSciBtn4.Location = new System.Drawing.Point(862, 285);
            this.cmpSciBtn4.Name = "cmpSciBtn4";
            this.cmpSciBtn4.Size = new System.Drawing.Size(164, 62);
            this.cmpSciBtn4.TabIndex = 24;
            this.cmpSciBtn4.Text = "$800";
            this.cmpSciBtn4.UseVisualStyleBackColor = true;
            this.cmpSciBtn4.Click += new System.EventHandler(this.CmpSciBtn4_Click);
            // 
            // qstnLbl
            // 
            this.qstnLbl.BackColor = System.Drawing.Color.Transparent;
            this.qstnLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qstnLbl.Location = new System.Drawing.Point(13, 380);
            this.qstnLbl.Name = "qstnLbl";
            this.qstnLbl.Size = new System.Drawing.Size(1013, 23);
            this.qstnLbl.TabIndex = 38;
            this.qstnLbl.Text = "Let\'s get ready to play Tech Jeopardy!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Tech_Jeopardy.Properties.Resources.RedAvatar;
            this.pictureBox2.Location = new System.Drawing.Point(10, 120);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(126, 103);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 37;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tech_Jeopardy.Properties.Resources.Piano;
            this.pictureBox1.Location = new System.Drawing.Point(11, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 103);
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // usrAnswrBtn
            // 
            this.usrAnswrBtn.BackColor = System.Drawing.Color.Transparent;
            this.usrAnswrBtn.BackgroundImage = global::Tech_Jeopardy.Properties.Resources.RedAnswerBtn;
            this.usrAnswrBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.usrAnswrBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.usrAnswrBtn.Location = new System.Drawing.Point(142, 63);
            this.usrAnswrBtn.Name = "usrAnswrBtn";
            this.usrAnswrBtn.Size = new System.Drawing.Size(61, 49);
            this.usrAnswrBtn.TabIndex = 43;
            this.usrAnswrBtn.UseVisualStyleBackColor = false;
            this.usrAnswrBtn.Click += new System.EventHandler(this.UsrAnswrBtn_Click);
            // 
            // cpuAnswrBtn
            // 
            this.cpuAnswrBtn.BackColor = System.Drawing.Color.Transparent;
            this.cpuAnswrBtn.BackgroundImage = global::Tech_Jeopardy.Properties.Resources.RedAnswerBtn;
            this.cpuAnswrBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.cpuAnswrBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cpuAnswrBtn.Location = new System.Drawing.Point(142, 174);
            this.cpuAnswrBtn.Name = "cpuAnswrBtn";
            this.cpuAnswrBtn.Size = new System.Drawing.Size(61, 49);
            this.cpuAnswrBtn.TabIndex = 44;
            this.cpuAnswrBtn.UseVisualStyleBackColor = false;
            this.cpuAnswrBtn.Click += new System.EventHandler(this.CpuAnswrBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cpuRt_Or_WrngLbl);
            this.groupBox1.Controls.Add(this.useRt_Or_WrngLbl);
            this.groupBox1.Controls.Add(this.athenaScore);
            this.groupBox1.Controls.Add(this.humanScore);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.cpuAnswrBtn);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.usrAnswrBtn);
            this.groupBox1.Location = new System.Drawing.Point(16, 406);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1010, 233);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            // 
            // cpuRt_Or_WrngLbl
            // 
            this.cpuRt_Or_WrngLbl.BackColor = System.Drawing.Color.Transparent;
            this.cpuRt_Or_WrngLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpuRt_Or_WrngLbl.Location = new System.Drawing.Point(145, 154);
            this.cpuRt_Or_WrngLbl.Name = "cpuRt_Or_WrngLbl";
            this.cpuRt_Or_WrngLbl.Size = new System.Drawing.Size(58, 17);
            this.cpuRt_Or_WrngLbl.TabIndex = 52;
            // 
            // useRt_Or_WrngLbl
            // 
            this.useRt_Or_WrngLbl.BackColor = System.Drawing.Color.Transparent;
            this.useRt_Or_WrngLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useRt_Or_WrngLbl.Location = new System.Drawing.Point(142, 44);
            this.useRt_Or_WrngLbl.Name = "useRt_Or_WrngLbl";
            this.useRt_Or_WrngLbl.Size = new System.Drawing.Size(61, 16);
            this.useRt_Or_WrngLbl.TabIndex = 51;
            // 
            // athenaScore
            // 
            this.athenaScore.BackColor = System.Drawing.Color.Transparent;
            this.athenaScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.athenaScore.Location = new System.Drawing.Point(145, 130);
            this.athenaScore.Name = "athenaScore";
            this.athenaScore.Size = new System.Drawing.Size(58, 17);
            this.athenaScore.TabIndex = 50;
            this.athenaScore.Text = "$";
            // 
            // humanScore
            // 
            this.humanScore.BackColor = System.Drawing.Color.Transparent;
            this.humanScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.humanScore.Location = new System.Drawing.Point(142, 16);
            this.humanScore.Name = "humanScore";
            this.humanScore.Size = new System.Drawing.Size(61, 17);
            this.humanScore.TabIndex = 49;
            this.humanScore.Text = "$";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SlateGray;
            this.panel2.Controls.Add(this.cpuQstnLbl);
            this.panel2.Controls.Add(this.cpuTxtBx);
            this.panel2.Location = new System.Drawing.Point(222, 120);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 103);
            this.panel2.TabIndex = 46;
            // 
            // cpuQstnLbl
            // 
            this.cpuQstnLbl.BackColor = System.Drawing.Color.Transparent;
            this.cpuQstnLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpuQstnLbl.Location = new System.Drawing.Point(0, 4);
            this.cpuQstnLbl.Name = "cpuQstnLbl";
            this.cpuQstnLbl.Size = new System.Drawing.Size(776, 23);
            this.cpuQstnLbl.TabIndex = 42;
            // 
            // cpuTxtBx
            // 
            this.cpuTxtBx.Location = new System.Drawing.Point(3, 80);
            this.cpuTxtBx.Name = "cpuTxtBx";
            this.cpuTxtBx.Size = new System.Drawing.Size(146, 20);
            this.cpuTxtBx.TabIndex = 41;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SlateGray;
            this.panel1.Controls.Add(this.userTimerLbl);
            this.panel1.Controls.Add(this.usrTxtBx);
            this.panel1.Controls.Add(this.usrQstnLbl);
            this.panel1.Location = new System.Drawing.Point(222, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 103);
            this.panel1.TabIndex = 45;
            // 
            // userTimerLbl
            // 
            this.userTimerLbl.AutoSize = true;
            this.userTimerLbl.Location = new System.Drawing.Point(3, 7);
            this.userTimerLbl.Name = "userTimerLbl";
            this.userTimerLbl.Size = new System.Drawing.Size(0, 13);
            this.userTimerLbl.TabIndex = 48;
            // 
            // usrTxtBx
            // 
            this.usrTxtBx.Location = new System.Drawing.Point(3, 80);
            this.usrTxtBx.Name = "usrTxtBx";
            this.usrTxtBx.Size = new System.Drawing.Size(146, 20);
            this.usrTxtBx.TabIndex = 40;
            this.usrTxtBx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.UserPressedEnter);
            // 
            // usrQstnLbl
            // 
            this.usrQstnLbl.BackColor = System.Drawing.Color.Transparent;
            this.usrQstnLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usrQstnLbl.Location = new System.Drawing.Point(0, 1);
            this.usrQstnLbl.Name = "usrQstnLbl";
            this.usrQstnLbl.Size = new System.Drawing.Size(779, 23);
            this.usrQstnLbl.TabIndex = 39;
            this.usrQstnLbl.Text = "Let\'s get ready to play tech jeopardy!";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 642);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1013, 23);
            this.label2.TabIndex = 46;
            this.label2.Text = "Coded By: McKinnely Bentley";
            // 
            // timerLbl
            // 
            this.timerLbl.BackColor = System.Drawing.Color.Transparent;
            this.timerLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timerLbl.Location = new System.Drawing.Point(60, 363);
            this.timerLbl.Name = "timerLbl";
            this.timerLbl.Size = new System.Drawing.Size(32, 17);
            this.timerLbl.TabIndex = 47;
            // 
            // timeLabel
            // 
            this.timeLabel.BackColor = System.Drawing.Color.Transparent;
            this.timeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLabel.Location = new System.Drawing.Point(13, 363);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(50, 17);
            this.timeLabel.TabIndex = 48;
            this.timeLabel.Text = "Timer:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1042, 669);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.timerLbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.qstnLbl);
            this.Controls.Add(this.cmpTiaSecBtn4);
            this.Controls.Add(this.linuxBtn4);
            this.Controls.Add(this.cSharpBtn4);
            this.Controls.Add(this.javaBtn4);
            this.Controls.Add(this.ntwrkBtn4);
            this.Controls.Add(this.cmpSciBtn4);
            this.Controls.Add(this.cmpTiaSecBtn3);
            this.Controls.Add(this.linuxBtn3);
            this.Controls.Add(this.cSharpBtn3);
            this.Controls.Add(this.javaBtn3);
            this.Controls.Add(this.ntwrkBtn3);
            this.Controls.Add(this.cmpSciBtn3);
            this.Controls.Add(this.cmpTiaSecBtn2);
            this.Controls.Add(this.linuxBtn2);
            this.Controls.Add(this.cSharpBtn2);
            this.Controls.Add(this.javaBtn2);
            this.Controls.Add(this.ntwrkBtn2);
            this.Controls.Add(this.cmpSciBtn2);
            this.Controls.Add(this.cmpTiaSecBtn1);
            this.Controls.Add(this.linuxBtn1);
            this.Controls.Add(this.cSharpBtn1);
            this.Controls.Add(this.javaBtn1);
            this.Controls.Add(this.ntwrkBtn1);
            this.Controls.Add(this.cmpSciBtn1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Tech Jeopardy";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button cmpTiaSecBtn1;
        private System.Windows.Forms.Button linuxBtn1;
        private System.Windows.Forms.Button cSharpBtn1;
        private System.Windows.Forms.Button javaBtn1;
        private System.Windows.Forms.Button ntwrkBtn1;
        private System.Windows.Forms.Button cmpSciBtn1;
        private System.Windows.Forms.Button cmpTiaSecBtn2;
        private System.Windows.Forms.Button linuxBtn2;
        private System.Windows.Forms.Button cSharpBtn2;
        private System.Windows.Forms.Button javaBtn2;
        private System.Windows.Forms.Button ntwrkBtn2;
        private System.Windows.Forms.Button cmpSciBtn2;
        private System.Windows.Forms.Button cmpTiaSecBtn3;
        private System.Windows.Forms.Button linuxBtn3;
        private System.Windows.Forms.Button cSharpBtn3;
        private System.Windows.Forms.Button javaBtn3;
        private System.Windows.Forms.Button ntwrkBtn3;
        private System.Windows.Forms.Button cmpSciBtn3;
        private System.Windows.Forms.Button cmpTiaSecBtn4;
        private System.Windows.Forms.Button linuxBtn4;
        private System.Windows.Forms.Button cSharpBtn4;
        private System.Windows.Forms.Button javaBtn4;
        private System.Windows.Forms.Button ntwrkBtn4;
        private System.Windows.Forms.Button cmpSciBtn4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label qstnLbl;
        private System.Windows.Forms.Button usrAnswrBtn;
        private System.Windows.Forms.Button cpuAnswrBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label timerLbl;
        private System.Windows.Forms.Label usrQstnLbl;
        private System.Windows.Forms.TextBox usrTxtBx;
        private System.Windows.Forms.TextBox cpuTxtBx;
        private System.Windows.Forms.Label cpuQstnLbl;
        private System.Windows.Forms.Label userTimerLbl;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label athenaScore;
        private System.Windows.Forms.Label humanScore;
        private System.Windows.Forms.Label cpuRt_Or_WrngLbl;
        private System.Windows.Forms.Label useRt_Or_WrngLbl;
    }
}

